create view new_view(author_id, num) as
SELECT author_id,
       count(*) AS num
FROM books
GROUP BY author_id
ORDER BY (count(*)) DESC
LIMIT 15;

alter table new_view
    owner to postgres;

