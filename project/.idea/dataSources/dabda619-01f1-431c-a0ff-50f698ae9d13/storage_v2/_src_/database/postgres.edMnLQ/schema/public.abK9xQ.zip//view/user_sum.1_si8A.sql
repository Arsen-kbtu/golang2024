create view user_sum(id, first_name, last_name, total_spending) as
SELECT users.id,
       users.first_name,
       users.last_name,
       COALESCE(sum(p.price), 0::bigint) AS total_spending
FROM users
         JOIN orders o ON users.id = o.user_id
         JOIN products p ON o.product_id = p.id
GROUP BY users.id, users.first_name, users.last_name;

alter table user_sum
    owner to postgres;

