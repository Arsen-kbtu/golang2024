create function division(first integer, second integer, OUT result numeric) returns numeric
    language plpgsql
as
$$
begin
    if(second=0) then raise exception 'Division by zero is not allowed.';
    end if;
    result:=first/second;
end;
$$;

alter function division(integer, integer, out numeric) owner to postgres;

