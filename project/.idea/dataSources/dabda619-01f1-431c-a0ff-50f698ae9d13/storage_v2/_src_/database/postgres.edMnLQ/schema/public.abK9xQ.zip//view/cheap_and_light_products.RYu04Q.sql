create view cheap_and_light_products(id, name, department, price, weight) as
SELECT id,
       name,
       department,
       price,
       weight
FROM products
WHERE price < 100
  AND weight < 10;

alter table cheap_and_light_products
    owner to postgres;

