create function greeting(name character varying) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN 'Hello, ' || name || '!';
END;
$$;

alter function greeting(varchar) owner to postgres;

