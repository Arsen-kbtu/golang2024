create function area(radius integer) returns character varying
    language plpgsql
as
$$
BEGIN
    RETURN 'Area of circle is ' || 3.14*(radius^2) || '!';
END;
$$;

alter function area(integer) owner to postgres;

