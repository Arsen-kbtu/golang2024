create view dep_max(department, highest_price) as
SELECT department,
       max(price) AS highest_price
FROM products
GROUP BY department;

alter table dep_max
    owner to postgres;

