create view order_user(fullname, id) as
SELECT concat(users.first_name, ' ', users.last_name) AS fullname,
       users.id
FROM users
         JOIN orders o ON users.id = o.user_id
WHERE o.paid = false;

alter table order_user
    owner to postgres;

