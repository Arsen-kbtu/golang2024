create function get_price_boundaries_by_paid(is_paid boolean DEFAULT true)
    returns TABLE(min_price integer, max_price integer)
    language plpgsql
as
$$BEGIN
return query
select min(price), max(price)
from orders
join public.products p on p.id = orders.product_id
where paid=is_paid;
end;
$$;

alter function get_price_boundaries_by_paid(boolean) owner to postgres;

