create function get_sum_avg_prices()
    returns TABLE(department_name character varying, total_price integer, avg_price integer)
    language plpgsql
as
$$BEGIN
return query
select
    department, sum(price)::int, avg(price)::int
from orders
join public.products p on p.id = orders.product_id
group by department;
end;
$$;

alter function get_sum_avg_prices() owner to postgres;

